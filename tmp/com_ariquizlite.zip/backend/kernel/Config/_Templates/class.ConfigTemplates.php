<?php
define('ARI_CONFIG_CACHE_TEMPLATE', "<?php\r\nif (!isset(\$GLOBALS['%1\$s'])) \$GLOBALS['%1\$s'] = %2\$s;\r\n?>");
?>