<?php
	defined('ARI_FRAMEWORK_LOADED') or die('Direct Access to this location is not allowed.');
	
	$version = $processPage->getVar('version');
?>

<div>
	<a href="http://www.ari-soft.com/Joomla-Components/ARI-Quiz-Lite/Detailed-product-flyer.html" target="_blank">ARI Quiz Lite</a> is quiz component provides ability to create various tests to evaluate respondent's level of knowledge.
</div>
<div>
	<br/>
	<b>Version:</b>
	<br/>
	<br/>
	<?php echo $version; ?>
</div>
<div>
	<br/>
	<b>Copyright:</b>
	<br/>
	<br/>
	&copy; 2009 <a href="http://www.ari-soft.com" target="_blank" title="ARI Soft">ARI Soft</a>
</div>
<div>
	<br/>
	<b>Links:</b>
	<br/>
	<br/>
	<a href="http://www.ari-soft.com/Joomla-Components/ARI-Quiz-Lite/Detailed-product-flyer.html" target="_blank">ARI Quiz Lite Home Page</a>
	<br/>
	<a href="http://www.ari-soft.com/ARI-Quiz-Lite/" target="_blank">ARI Quiz Lite Support</a>
</div>