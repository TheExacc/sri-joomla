<?php
/*
 *
 * @package		ARI Quiz Lite
 * @author		ARI Soft
 * @copyright	Copyright (c) 2011 www.ari-soft.com. All rights reserved
 * @license		GNU/GPL (http://www.gnu.org/copyleft/gpl.html)
 * 
 */

defined('_JEXEC') or die;

require_once dirname(__FILE__) . '/uninstall.php';